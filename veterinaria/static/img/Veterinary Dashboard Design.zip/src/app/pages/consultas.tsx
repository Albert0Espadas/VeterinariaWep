import { useState } from "react";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../components/ui/dialog";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Search, Plus, Stethoscope, Calendar, FileText, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

interface Consultation {
  id: string;
  petName: string;
  ownerName: string;
  date: Date;
  reason: string;
  diagnosis: string;
  treatment: string;
  status: "completada" | "en-progreso" | "pendiente";
  veterinarian: string;
}

export function Consultas() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("todas");

  const consultations: Consultation[] = [
    {
      id: "1",
      petName: "Max",
      ownerName: "Juan Pérez",
      date: new Date(2026, 2, 16, 9, 0),
      reason: "Revisión general",
      diagnosis: "Estado de salud normal",
      treatment: "Vacuna antirrábica aplicada",
      status: "completada",
      veterinarian: "Dra. Laura Mendoza"
    },
    {
      id: "2",
      petName: "Luna",
      ownerName: "María García",
      date: new Date(2026, 2, 16, 10, 30),
      reason: "Vómitos y pérdida de apetito",
      diagnosis: "Gastritis leve",
      treatment: "Dieta blanda por 3 días + antiemético",
      status: "en-progreso",
      veterinarian: "Dr. Carlos Ramírez"
    },
    {
      id: "3",
      petName: "Rocky",
      ownerName: "Carlos López",
      date: new Date(2026, 2, 16, 12, 0),
      reason: "Control post-operatorio",
      diagnosis: "Cicatrización adecuada",
      treatment: "Continuar con antibiótico 5 días más",
      status: "completada",
      veterinarian: "Dra. Laura Mendoza"
    },
    {
      id: "4",
      petName: "Mía",
      ownerName: "Ana Martínez",
      date: new Date(2026, 2, 16, 14, 0),
      reason: "Cojera en pata trasera",
      diagnosis: "Pendiente de radiografía",
      treatment: "Antiinflamatorio prescrito",
      status: "pendiente",
      veterinarian: "Dr. Carlos Ramírez"
    },
    {
      id: "5",
      petName: "Toby",
      ownerName: "Luis Rodríguez",
      date: new Date(2026, 2, 15, 16, 0),
      reason: "Picazón y caída de pelo",
      diagnosis: "Dermatitis alérgica",
      treatment: "Shampoo medicado + antihistamínico",
      status: "completada",
      veterinarian: "Dra. Laura Mendoza"
    },
  ];

  const filteredConsultations = consultations.filter(consultation => {
    const matchesSearch = 
      consultation.petName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      consultation.ownerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      consultation.reason.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "todas" || consultation.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completada":
        return "bg-green-100 text-green-700";
      case "en-progreso":
        return "bg-amber-100 text-amber-700";
      case "pendiente":
        return "bg-red-100 text-red-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "completada":
        return "Completada";
      case "en-progreso":
        return "En Progreso";
      case "pendiente":
        return "Pendiente";
      default:
        return status;
    }
  };

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-foreground">Consultas</h1>
          <p className="text-muted-foreground mt-1">Gestión de consultas veterinarias</p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90">
              <Plus className="w-4 h-4 mr-2" />
              Nueva Consulta
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Registrar Nueva Consulta</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Mascota</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar mascota" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">Max - Juan Pérez</SelectItem>
                      <SelectItem value="2">Luna - María García</SelectItem>
                      <SelectItem value="3">Rocky - Carlos López</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Veterinario</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar veterinario" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">Dra. Laura Mendoza</SelectItem>
                      <SelectItem value="2">Dr. Carlos Ramírez</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Motivo de Consulta</Label>
                <Input placeholder="Ej. Revisión general, síntomas..." />
              </div>
              <div className="space-y-2">
                <Label>Diagnóstico</Label>
                <Textarea placeholder="Descripción del diagnóstico..." rows={3} />
              </div>
              <div className="space-y-2">
                <Label>Tratamiento</Label>
                <Textarea placeholder="Tratamiento prescrito..." rows={3} />
              </div>
              <div className="space-y-2">
                <Label>Estado</Label>
                <Select defaultValue="en-progreso">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pendiente">Pendiente</SelectItem>
                    <SelectItem value="en-progreso">En Progreso</SelectItem>
                    <SelectItem value="completada">Completada</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button className="w-full bg-primary hover:bg-primary/90">Registrar Consulta</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            placeholder="Buscar por mascota, dueño o motivo..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-white"
          />
        </div>
        <div className="flex gap-2">
          <Button
            variant={statusFilter === "todas" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("todas")}
            className={statusFilter === "todas" ? "bg-primary hover:bg-primary/90" : ""}
          >
            Todas
          </Button>
          <Button
            variant={statusFilter === "pendiente" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("pendiente")}
            className={statusFilter === "pendiente" ? "bg-primary hover:bg-primary/90" : ""}
          >
            Pendientes
          </Button>
          <Button
            variant={statusFilter === "en-progreso" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("en-progreso")}
            className={statusFilter === "en-progreso" ? "bg-primary hover:bg-primary/90" : ""}
          >
            En Progreso
          </Button>
          <Button
            variant={statusFilter === "completada" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("completada")}
            className={statusFilter === "completada" ? "bg-primary hover:bg-primary/90" : ""}
          >
            Completadas
          </Button>
        </div>
      </div>

      {/* Consultations List */}
      <div className="space-y-4">
        {filteredConsultations.map((consultation) => (
          <Card key={consultation.id} className="p-6 border-border hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4 flex-1">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent-foreground flex items-center justify-center flex-shrink-0">
                  <Stethoscope className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 space-y-3">
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="font-semibold text-lg">{consultation.petName}</h3>
                      <Badge className={getStatusColor(consultation.status)}>
                        {getStatusLabel(consultation.status)}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{consultation.ownerName}</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="w-4 h-4 text-muted-foreground" />
                        <span className="text-muted-foreground">
                          {format(consultation.date, "d 'de' MMMM 'de' yyyy, HH:mm", { locale: es })}
                        </span>
                      </div>
                      <div className="flex items-start gap-2 text-sm">
                        <FileText className="w-4 h-4 text-muted-foreground mt-0.5" />
                        <div>
                          <p className="text-muted-foreground">Veterinario:</p>
                          <p className="font-medium">{consultation.veterinarian}</p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-start gap-2 text-sm">
                        <AlertCircle className="w-4 h-4 text-muted-foreground mt-0.5" />
                        <div>
                          <p className="text-muted-foreground">Motivo:</p>
                          <p className="font-medium">{consultation.reason}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div>
                      <p className="text-muted-foreground">Diagnóstico:</p>
                      <p>{consultation.diagnosis}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Tratamiento:</p>
                      <p>{consultation.treatment}</p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      Ver Detalles
                    </Button>
                    <Button size="sm" className="bg-primary hover:bg-primary/90">
                      Editar Consulta
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
