import { useParams, useNavigate } from "react-router";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { 
  ArrowLeft, 
  PawPrint, 
  Calendar, 
  Stethoscope, 
  Syringe,
  FileText,
  Activity,
  Pill
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

interface MedicalRecord {
  id: string;
  date: Date;
  type: "consulta" | "vacuna" | "cirugia" | "examen";
  veterinarian: string;
  diagnosis: string;
  treatment: string;
  notes?: string;
}

interface Vaccine {
  id: string;
  name: string;
  date: Date;
  nextDate?: Date;
  veterinarian: string;
}

interface PetInfo {
  id: string;
  name: string;
  species: string;
  breed: string;
  age: string;
  weight: string;
  ownerName: string;
  ownerPhone: string;
  ownerEmail: string;
}

export function HistorialMedico() {
  const { petId } = useParams();
  const navigate = useNavigate();

  // Mock data - en una app real vendría de una API
  const petInfo: PetInfo = {
    id: petId || "1",
    name: "Max",
    species: "Perro",
    breed: "Golden Retriever",
    age: "3 años",
    weight: "32 kg",
    ownerName: "Juan Pérez",
    ownerPhone: "+52 555-1234",
    ownerEmail: "juan@email.com"
  };

  const medicalRecords: MedicalRecord[] = [
    {
      id: "1",
      date: new Date(2026, 2, 16),
      type: "consulta",
      veterinarian: "Dra. Laura Mendoza",
      diagnosis: "Estado de salud normal",
      treatment: "Vacuna antirrábica aplicada",
      notes: "Paciente en excelente condición física"
    },
    {
      id: "2",
      date: new Date(2026, 1, 10),
      type: "vacuna",
      veterinarian: "Dr. Carlos Ramírez",
      diagnosis: "Aplicación de refuerzo",
      treatment: "Vacuna polivalente (DHPPi)",
    },
    {
      id: "3",
      date: new Date(2026, 0, 5),
      type: "examen",
      veterinarian: "Dra. Laura Mendoza",
      diagnosis: "Análisis de sangre - Resultados normales",
      treatment: "Control anual completo",
      notes: "Todos los valores dentro del rango normal"
    },
    {
      id: "4",
      date: new Date(2025, 11, 15),
      type: "consulta",
      veterinarian: "Dr. Carlos Ramírez",
      diagnosis: "Otitis leve",
      treatment: "Gotas óticas - 7 días",
      notes: "Limpieza de oídos realizada"
    }
  ];

  const vaccines: Vaccine[] = [
    {
      id: "1",
      name: "Antirrábica",
      date: new Date(2026, 2, 16),
      nextDate: new Date(2027, 2, 16),
      veterinarian: "Dra. Laura Mendoza"
    },
    {
      id: "2",
      name: "Polivalente (DHPPi)",
      date: new Date(2026, 1, 10),
      nextDate: new Date(2027, 1, 10),
      veterinarian: "Dr. Carlos Ramírez"
    },
    {
      id: "3",
      name: "Leptospirosis",
      date: new Date(2025, 10, 20),
      nextDate: new Date(2026, 10, 20),
      veterinarian: "Dra. Laura Mendoza"
    }
  ];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "consulta":
        return <Stethoscope className="w-5 h-5" />;
      case "vacuna":
        return <Syringe className="w-5 h-5" />;
      case "cirugia":
        return <Activity className="w-5 h-5" />;
      case "examen":
        return <FileText className="w-5 h-5" />;
      default:
        return <FileText className="w-5 h-5" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "consulta":
        return "Consulta";
      case "vacuna":
        return "Vacunación";
      case "cirugia":
        return "Cirugía";
      case "examen":
        return "Examen";
      default:
        return type;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "consulta":
        return "bg-blue-100 text-blue-700";
      case "vacuna":
        return "bg-green-100 text-green-700";
      case "cirugia":
        return "bg-red-100 text-red-700";
      case "examen":
        return "bg-purple-100 text-purple-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate("/recepcion")}
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-semibold text-foreground">Historial Médico</h1>
          <p className="text-muted-foreground mt-1">Registro completo de atención veterinaria</p>
        </div>
      </div>

      {/* Pet Information Card */}
      <Card className="p-6 border-border bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="flex items-start gap-6">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
            <PawPrint className="w-10 h-10 text-white" />
          </div>
          <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <h2 className="text-2xl font-semibold mb-2">{petInfo.name}</h2>
              <div className="space-y-1 text-sm">
                <p><span className="text-muted-foreground">Especie:</span> {petInfo.species}</p>
                <p><span className="text-muted-foreground">Raza:</span> {petInfo.breed}</p>
                <p><span className="text-muted-foreground">Edad:</span> {petInfo.age}</p>
                <p><span className="text-muted-foreground">Peso:</span> {petInfo.weight}</p>
              </div>
            </div>
            <div className="md:col-span-2">
              <h3 className="font-semibold mb-2">Información del Dueño</h3>
              <div className="space-y-1 text-sm">
                <p><span className="text-muted-foreground">Nombre:</span> {petInfo.ownerName}</p>
                <p><span className="text-muted-foreground">Teléfono:</span> {petInfo.ownerPhone}</p>
                <p><span className="text-muted-foreground">Email:</span> {petInfo.ownerEmail}</p>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Medical History Tabs */}
      <Tabs defaultValue="historial">
        <TabsList className="bg-secondary">
          <TabsTrigger value="historial">Historial Médico</TabsTrigger>
          <TabsTrigger value="vacunas">Vacunas</TabsTrigger>
          <TabsTrigger value="resumen">Resumen</TabsTrigger>
        </TabsList>

        {/* Medical History Tab */}
        <TabsContent value="historial" className="space-y-4">
          <div className="space-y-4">
            {medicalRecords.map((record) => (
              <Card key={record.id} className="p-6 border-border hover:shadow-md transition-shadow">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
                    {getTypeIcon(record.type)}
                    <span className="text-white">{getTypeIcon(record.type)}</span>
                  </div>
                  <div className="flex-1 space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-3 mb-1">
                          <h3 className="font-semibold text-lg">
                            {getTypeLabel(record.type)}
                          </h3>
                          <Badge className={getTypeColor(record.type)}>
                            {getTypeLabel(record.type)}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="w-4 h-4" />
                          <span>{format(record.date, "d 'de' MMMM 'de' yyyy", { locale: es })}</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div>
                        <p className="text-sm text-muted-foreground">Veterinario:</p>
                        <p className="font-medium">{record.veterinarian}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Diagnóstico:</p>
                        <p>{record.diagnosis}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Tratamiento:</p>
                        <p>{record.treatment}</p>
                      </div>
                      {record.notes && (
                        <div className="p-3 bg-secondary/50 rounded-lg">
                          <p className="text-sm text-muted-foreground mb-1">Notas:</p>
                          <p className="text-sm">{record.notes}</p>
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Ver Detalles
                      </Button>
                      <Button size="sm" className="bg-primary hover:bg-primary/90">
                        Editar
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Vaccines Tab */}
        <TabsContent value="vacunas" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {vaccines.map((vaccine) => (
              <Card key={vaccine.id} className="p-6 border-border hover:shadow-md transition-shadow">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center flex-shrink-0">
                    <Syringe className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1 space-y-3">
                    <div>
                      <h3 className="font-semibold text-lg">{vaccine.name}</h3>
                      <p className="text-sm text-muted-foreground">{vaccine.veterinarian}</p>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-muted-foreground" />
                        <div>
                          <p className="text-muted-foreground">Aplicada:</p>
                          <p className="font-medium">
                            {format(vaccine.date, "d 'de' MMMM 'de' yyyy", { locale: es })}
                          </p>
                        </div>
                      </div>
                      {vaccine.nextDate && (
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-muted-foreground" />
                          <div>
                            <p className="text-muted-foreground">Próxima dosis:</p>
                            <p className="font-medium text-primary">
                              {format(vaccine.nextDate, "d 'de' MMMM 'de' yyyy", { locale: es })}
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Summary Tab */}
        <TabsContent value="resumen" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-6 border-border">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <FileText className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Consultas</p>
                  <p className="text-2xl font-semibold">{medicalRecords.filter(r => r.type === "consulta").length}</p>
                </div>
              </div>
            </Card>
            <Card className="p-6 border-border">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <Syringe className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Vacunas</p>
                  <p className="text-2xl font-semibold">{vaccines.length}</p>
                </div>
              </div>
            </Card>
            <Card className="p-6 border-border">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Activity className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Última Visita</p>
                  <p className="text-2xl font-semibold">
                    {format(medicalRecords[0].date, "d MMM", { locale: es })}
                  </p>
                </div>
              </div>
            </Card>
          </div>

          <Card className="p-6 border-border">
            <h3 className="font-semibold text-lg mb-4">Próximas Vacunas</h3>
            <div className="space-y-3">
              {vaccines
                .filter(v => v.nextDate && v.nextDate > new Date())
                .sort((a, b) => (a.nextDate!.getTime() - b.nextDate!.getTime()))
                .map((vaccine) => (
                  <div key={vaccine.id} className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Pill className="w-5 h-5 text-primary" />
                      <div>
                        <p className="font-medium">{vaccine.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {format(vaccine.nextDate!, "d 'de' MMMM 'de' yyyy", { locale: es })}
                        </p>
                      </div>
                    </div>
                    <Badge variant="secondary">Pendiente</Badge>
                  </div>
                ))}
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
