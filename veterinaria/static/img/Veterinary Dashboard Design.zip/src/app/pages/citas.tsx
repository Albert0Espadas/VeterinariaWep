import { useState } from "react";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../components/ui/dialog";
import { Label } from "../components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Calendar as CalendarIcon, Clock, Plus, User, PawPrint, CheckCircle2, XCircle } from "lucide-react";
import { format, addDays, startOfWeek, addWeeks } from "date-fns";
import { es } from "date-fns/locale";

interface Appointment {
  id: string;
  petName: string;
  ownerName: string;
  date: Date;
  time: string;
  service: string;
  veterinarian: string;
  status: "confirmada" | "pendiente" | "cancelada";
  notes?: string;
}

export function Citas() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<"day" | "week">("day");

  const appointments: Appointment[] = [
    {
      id: "1",
      petName: "Max",
      ownerName: "Juan Pérez",
      date: new Date(2026, 2, 16),
      time: "09:00",
      service: "Consulta general",
      veterinarian: "Dra. Laura Mendoza",
      status: "confirmada",
      notes: "Primera visita"
    },
    {
      id: "2",
      petName: "Luna",
      ownerName: "María García",
      date: new Date(2026, 2, 16),
      time: "10:30",
      service: "Vacunación",
      veterinarian: "Dr. Carlos Ramírez",
      status: "confirmada"
    },
    {
      id: "3",
      petName: "Rocky",
      ownerName: "Carlos López",
      date: new Date(2026, 2, 16),
      time: "12:00",
      service: "Control post-operatorio",
      veterinarian: "Dra. Laura Mendoza",
      status: "pendiente"
    },
    {
      id: "4",
      petName: "Mía",
      ownerName: "Ana Martínez",
      date: new Date(2026, 2, 17),
      time: "09:30",
      service: "Cirugía menor",
      veterinarian: "Dra. Laura Mendoza",
      status: "confirmada",
      notes: "Requiere ayuno de 8 horas"
    },
    {
      id: "5",
      petName: "Toby",
      ownerName: "Luis Rodríguez",
      date: new Date(2026, 2, 17),
      time: "14:00",
      service: "Baño y corte",
      veterinarian: "Dr. Carlos Ramírez",
      status: "confirmada"
    },
    {
      id: "6",
      petName: "Bella",
      ownerName: "Carmen Torres",
      date: new Date(2026, 2, 18),
      time: "11:00",
      service: "Desparasitación",
      veterinarian: "Dra. Laura Mendoza",
      status: "pendiente"
    },
  ];

  const timeSlots = [
    "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
    "12:00", "12:30", "14:00", "14:30", "15:00", "15:30",
    "16:00", "16:30", "17:00", "17:30"
  ];

  const getAppointmentsForDate = (date: Date) => {
    return appointments.filter(apt => 
      format(apt.date, "yyyy-MM-dd") === format(date, "yyyy-MM-dd")
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmada":
        return "bg-green-100 text-green-700 border-green-200";
      case "pendiente":
        return "bg-amber-100 text-amber-700 border-amber-200";
      case "cancelada":
        return "bg-red-100 text-red-700 border-red-200";
      default:
        return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const weekStart = startOfWeek(selectedDate, { weekStartsOn: 1 });
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-foreground">Citas</h1>
          <p className="text-muted-foreground mt-1">Gestión del calendario de citas</p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90">
              <Plus className="w-4 h-4 mr-2" />
              Nueva Cita
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Agendar Nueva Cita</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Mascota</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar mascota" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Max - Juan Pérez</SelectItem>
                    <SelectItem value="2">Luna - María García</SelectItem>
                    <SelectItem value="3">Rocky - Carlos López</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Fecha</Label>
                  <Input type="date" />
                </div>
                <div className="space-y-2">
                  <Label>Hora</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar" />
                    </SelectTrigger>
                    <SelectContent>
                      {timeSlots.map(time => (
                        <SelectItem key={time} value={time}>{time}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Servicio</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar servicio" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="consulta">Consulta general</SelectItem>
                    <SelectItem value="vacunacion">Vacunación</SelectItem>
                    <SelectItem value="cirugia">Cirugía</SelectItem>
                    <SelectItem value="bano">Baño y corte</SelectItem>
                    <SelectItem value="control">Control</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Veterinario</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar veterinario" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Dra. Laura Mendoza</SelectItem>
                    <SelectItem value="2">Dr. Carlos Ramírez</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Notas (opcional)</Label>
                <Input placeholder="Información adicional..." />
              </div>
              <Button className="w-full bg-primary hover:bg-primary/90">Agendar Cita</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* View Mode Toggle */}
      <div className="flex items-center gap-2">
        <Button
          variant={viewMode === "day" ? "default" : "outline"}
          size="sm"
          onClick={() => setViewMode("day")}
          className={viewMode === "day" ? "bg-primary hover:bg-primary/90" : ""}
        >
          Vista Diaria
        </Button>
        <Button
          variant={viewMode === "week" ? "default" : "outline"}
          size="sm"
          onClick={() => setViewMode("week")}
          className={viewMode === "week" ? "bg-primary hover:bg-primary/90" : ""}
        >
          Vista Semanal
        </Button>
        <div className="ml-auto flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setSelectedDate(addDays(selectedDate, viewMode === "day" ? -1 : -7))}
          >
            ← Anterior
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setSelectedDate(new Date())}
          >
            Hoy
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setSelectedDate(addDays(selectedDate, viewMode === "day" ? 1 : 7))}
          >
            Siguiente →
          </Button>
        </div>
      </div>

      {/* Calendar View */}
      {viewMode === "day" ? (
        <Card className="p-6 border-border">
          <div className="mb-6">
            <h2 className="text-2xl font-semibold">
              {format(selectedDate, "EEEE, d 'de' MMMM 'de' yyyy", { locale: es })}
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              {getAppointmentsForDate(selectedDate).length} cita(s) programadas
            </p>
          </div>

          <div className="space-y-3">
            {getAppointmentsForDate(selectedDate).length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <CalendarIcon className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No hay citas programadas para este día</p>
              </div>
            ) : (
              getAppointmentsForDate(selectedDate).map((apt) => (
                <Card key={apt.id} className="p-4 border-border hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4 flex-1">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent-foreground flex items-center justify-center flex-shrink-0">
                        <Clock className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <span className="text-lg font-semibold text-primary">{apt.time}</span>
                          <Badge className={getStatusColor(apt.status)}>
                            {apt.status === "confirmada" ? "Confirmada" : apt.status === "pendiente" ? "Pendiente" : "Cancelada"}
                          </Badge>
                        </div>
                        <h3 className="font-semibold">{apt.petName}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2 text-sm text-muted-foreground">
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4" />
                            <span>{apt.ownerName}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <PawPrint className="w-4 h-4" />
                            <span>{apt.service}</span>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Veterinario: {apt.veterinarian}
                        </p>
                        {apt.notes && (
                          <p className="text-sm mt-2 p-2 bg-secondary/50 rounded">
                            <span className="font-medium">Nota:</span> {apt.notes}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {apt.status !== "confirmada" && (
                        <Button size="sm" variant="outline" className="text-green-600 hover:bg-green-50">
                          <CheckCircle2 className="w-4 h-4" />
                        </Button>
                      )}
                      {apt.status !== "cancelada" && (
                        <Button size="sm" variant="outline" className="text-red-600 hover:bg-red-50">
                          <XCircle className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>
        </Card>
      ) : (
        <Card className="p-6 border-border overflow-x-auto">
          <div className="mb-6">
            <h2 className="text-2xl font-semibold">
              Semana del {format(weekStart, "d 'de' MMMM", { locale: es })} al {format(addDays(weekStart, 6), "d 'de' MMMM 'de' yyyy", { locale: es })}
            </h2>
          </div>

          <div className="min-w-[900px]">
            <div className="grid grid-cols-8 gap-2 mb-2">
              <div className="text-sm font-medium text-muted-foreground">Hora</div>
              {weekDays.map(day => (
                <div key={day.toString()} className="text-center">
                  <div className="text-sm font-medium">
                    {format(day, "EEE", { locale: es })}
                  </div>
                  <div className="text-lg font-semibold">
                    {format(day, "d", { locale: es })}
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-1">
              {timeSlots.map(time => (
                <div key={time} className="grid grid-cols-8 gap-2">
                  <div className="text-sm text-muted-foreground py-2">
                    {time}
                  </div>
                  {weekDays.map(day => {
                    const dayAppointments = getAppointmentsForDate(day).filter(
                      apt => apt.time === time
                    );
                    return (
                      <div key={`${day}-${time}`} className="min-h-[60px] border border-border rounded-lg p-1">
                        {dayAppointments.map(apt => (
                          <div
                            key={apt.id}
                            className={`text-xs p-2 rounded ${getStatusColor(apt.status)} cursor-pointer hover:opacity-80`}
                          >
                            <p className="font-medium truncate">{apt.petName}</p>
                            <p className="truncate opacity-90">{apt.service}</p>
                          </div>
                        ))}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
