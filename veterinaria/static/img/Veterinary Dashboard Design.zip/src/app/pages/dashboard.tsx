import { useState } from "react";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Checkbox } from "../components/ui/checkbox";
import { 
  Calendar, 
  Clock, 
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Users,
  PawPrint
} from "lucide-react";
import { format, addDays, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday } from "date-fns";
import { es } from "date-fns/locale";

interface Appointment {
  id: string;
  petName: string;
  ownerName: string;
  time: string;
  type: string;
  status: "pendiente" | "completada" | "cancelada";
}

interface Todo {
  id: string;
  text: string;
  completed: boolean;
  priority: "alta" | "media" | "baja";
}

export function Dashboard() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [todos, setTodos] = useState<Todo[]>([
    { id: "1", text: "Revisar inventario de medicamentos", completed: false, priority: "alta" },
    { id: "2", text: "Llamar a proveedor de alimentos", completed: false, priority: "media" },
    { id: "3", text: "Actualizar historial de Max", completed: true, priority: "baja" },
    { id: "4", text: "Preparar sala de cirugía para mañana", completed: false, priority: "alta" },
    { id: "5", text: "Enviar recordatorios de vacunación", completed: false, priority: "media" },
  ]);

  const appointments: Appointment[] = [
    { id: "1", petName: "Max", ownerName: "Juan Pérez", time: "09:00", type: "Consulta general", status: "completada" },
    { id: "2", petName: "Luna", ownerName: "María García", time: "10:30", type: "Vacunación", status: "pendiente" },
    { id: "3", petName: "Rocky", ownerName: "Carlos López", time: "12:00", type: "Control", status: "pendiente" },
    { id: "4", petName: "Mía", ownerName: "Ana Martínez", time: "14:00", type: "Cirugía menor", status: "pendiente" },
    { id: "5", petName: "Toby", ownerName: "Luis Rodríguez", time: "16:00", type: "Baño y corte", status: "pendiente" },
  ];

  const stats = [
    { label: "Citas Hoy", value: "12", icon: Calendar, color: "text-primary" },
    { label: "Pacientes Totales", value: "248", icon: PawPrint, color: "text-accent-foreground" },
    { label: "Clientes", value: "186", icon: Users, color: "text-muted-foreground" },
    { label: "Ingresos del Mes", value: "$45,230", icon: TrendingUp, color: "text-primary" },
  ];

  const toggleTodo = (id: string) => {
    setTodos(todos.map(todo => 
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  // Calendar logic
  const monthStart = startOfMonth(selectedDate);
  const monthEnd = endOfMonth(selectedDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });
  const startDay = monthStart.getDay();

  const appointmentDates = [
    new Date(),
    addDays(new Date(), 1),
    addDays(new Date(), 3),
    addDays(new Date(), 5),
  ];

  const hasAppointment = (date: Date) => {
    return appointmentDates.some(d => isSameDay(d, date));
  };

  return (
    <div className="p-8 space-y-6 bg-gradient-to-br from-pink-50/30 via-white/50 to-purple-50/30 min-h-full">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-semibold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          {format(new Date(), "EEEE, d 'de' MMMM 'de' yyyy", { locale: es })}
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className="p-6 border-purple-100 bg-white/80 backdrop-blur-sm hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl font-semibold mt-2 text-purple-900">{stat.value}</p>
                </div>
                <div className="p-3 rounded-xl bg-gradient-to-br from-purple-100 to-pink-100">
                  <Icon className="w-5 h-5 text-purple-600" />
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar */}
        <Card className="p-6 lg:col-span-2 border-purple-100 bg-white/80 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-purple-900">Calendario de Citas</h2>
            <div className="text-sm text-muted-foreground">
              {format(selectedDate, "MMMM yyyy", { locale: es })}
            </div>
          </div>

          <div className="space-y-4">
            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-2">
              {["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"].map((day) => (
                <div key={day} className="text-center text-sm font-medium text-muted-foreground py-2">
                  {day}
                </div>
              ))}
              
              {Array.from({ length: startDay }).map((_, i) => (
                <div key={`empty-${i}`} />
              ))}
              
              {daysInMonth.map((day) => {
                const today = isToday(day);
                const hasAppt = hasAppointment(day);
                return (
                  <button
                    key={day.toString()}
                    onClick={() => setSelectedDate(day)}
                    className={`
                      aspect-square rounded-xl p-2 text-sm transition-all relative
                      ${today ? "bg-gradient-to-br from-purple-500 to-pink-500 text-white font-semibold shadow-md" : "hover:bg-pink-50"}
                      ${isSameDay(day, selectedDate) && !today ? "bg-purple-100 text-purple-900" : ""}
                    `}
                  >
                    {format(day, "d")}
                    {hasAppt && (
                      <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-pink-500 rounded-full" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Today's Appointments */}
            <div className="mt-6 space-y-2">
              <h3 className="font-medium mb-3 text-purple-900">Citas de Hoy</h3>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {appointments.map((apt) => (
                  <div
                    key={apt.id}
                    className="flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-purple-50 to-pink-50 hover:shadow-md transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                        <Clock className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <p className="font-medium text-purple-900">{apt.petName} - {apt.ownerName}</p>
                        <p className="text-sm text-muted-foreground">{apt.type}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-medium text-purple-600">{apt.time}</span>
                      {apt.status === "completada" ? (
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                      ) : (
                        <AlertCircle className="w-5 h-5 text-amber-500" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Card>

        {/* Pendientes */}
        <Card className="p-6 border-purple-100 bg-white/80 backdrop-blur-sm">
          <h2 className="text-xl font-semibold mb-4 text-purple-900">Pendientes</h2>
          <div className="space-y-3 max-h-[600px] overflow-y-auto">
            {todos.map((todo) => (
              <div
                key={todo.id}
                className={`
                  flex items-start gap-3 p-3 rounded-xl transition-all
                  ${todo.completed ? "bg-gray-50" : "bg-gradient-to-r from-purple-50 to-pink-50 hover:shadow-md"}
                `}
              >
                <Checkbox
                  checked={todo.completed}
                  onCheckedChange={() => toggleTodo(todo.id)}
                  className="mt-1"
                />
                <div className="flex-1">
                  <p className={`${todo.completed ? "line-through text-muted-foreground" : "text-purple-900"}`}>
                    {todo.text}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <span
                      className={`
                        text-xs px-2 py-0.5 rounded-full
                        ${todo.priority === "alta" ? "bg-red-100 text-red-700" : ""}
                        ${todo.priority === "media" ? "bg-amber-100 text-amber-700" : ""}
                        ${todo.priority === "baja" ? "bg-green-100 text-green-700" : ""}
                      `}
                    >
                      {todo.priority}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <Button className="w-full mt-4 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-md">
            Agregar Pendiente
          </Button>
        </Card>
      </div>
    </div>
  );
}