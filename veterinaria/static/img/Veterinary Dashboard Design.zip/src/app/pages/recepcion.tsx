import { useState } from "react";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../components/ui/dialog";
import { Label } from "../components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Search, Plus, PawPrint, User, Phone, Mail, MapPin } from "lucide-react";
import { useNavigate } from "react-router";

interface Pet {
  id: string;
  name: string;
  species: string;
  breed: string;
  age: string;
  ownerId: string;
  ownerName: string;
  status: "activo" | "inactivo";
}

interface Owner {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  pets: number;
}

export function Recepcion() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("mascotas");

  const pets: Pet[] = [
    { id: "1", name: "Max", species: "Perro", breed: "Golden Retriever", age: "3 años", ownerId: "1", ownerName: "Juan Pérez", status: "activo" },
    { id: "2", name: "Luna", species: "Gato", breed: "Siamés", age: "2 años", ownerId: "2", ownerName: "María García", status: "activo" },
    { id: "3", name: "Rocky", species: "Perro", breed: "Bulldog", age: "5 años", ownerId: "3", ownerName: "Carlos López", status: "activo" },
    { id: "4", name: "Mía", species: "Gato", breed: "Persa", age: "1 año", ownerId: "4", ownerName: "Ana Martínez", status: "activo" },
    { id: "5", name: "Toby", species: "Perro", breed: "Labrador", age: "4 años", ownerId: "5", ownerName: "Luis Rodríguez", status: "activo" },
  ];

  const owners: Owner[] = [
    { id: "1", name: "Juan Pérez", phone: "+52 555-1234", email: "juan@email.com", address: "Av. Principal 123", pets: 1 },
    { id: "2", name: "María García", phone: "+52 555-5678", email: "maria@email.com", address: "Calle Norte 456", pets: 2 },
    { id: "3", name: "Carlos López", phone: "+52 555-9012", email: "carlos@email.com", address: "Col. Centro 789", pets: 1 },
    { id: "4", name: "Ana Martínez", phone: "+52 555-3456", email: "ana@email.com", address: "Zona Sur 321", pets: 1 },
    { id: "5", name: "Luis Rodríguez", phone: "+52 555-7890", email: "luis@email.com", address: "Fracc. Norte 654", pets: 3 },
  ];

  const filteredPets = pets.filter(pet =>
    pet.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    pet.ownerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    pet.breed.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredOwners = owners.filter(owner =>
    owner.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    owner.phone.includes(searchTerm) ||
    owner.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-foreground">Recepción</h1>
          <p className="text-muted-foreground mt-1">Gestión de mascotas y clientes</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-secondary">
          <TabsTrigger value="mascotas">Mascotas</TabsTrigger>
          <TabsTrigger value="clientes">Clientes</TabsTrigger>
        </TabsList>

        {/* Mascotas Tab */}
        <TabsContent value="mascotas" className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Buscar mascotas por nombre, dueño o raza..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white"
              />
            </div>
            <Dialog>
              <DialogTrigger asChild>
                <Button className="bg-primary hover:bg-primary/90">
                  <Plus className="w-4 h-4 mr-2" />
                  Nueva Mascota
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Registrar Nueva Mascota</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label>Nombre de la Mascota</Label>
                    <Input placeholder="Ej. Max" />
                  </div>
                  <div className="space-y-2">
                    <Label>Especie</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="perro">Perro</SelectItem>
                        <SelectItem value="gato">Gato</SelectItem>
                        <SelectItem value="ave">Ave</SelectItem>
                        <SelectItem value="otro">Otro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Raza</Label>
                    <Input placeholder="Ej. Golden Retriever" />
                  </div>
                  <div className="space-y-2">
                    <Label>Edad</Label>
                    <Input placeholder="Ej. 3 años" />
                  </div>
                  <div className="space-y-2">
                    <Label>Dueño</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar dueño" />
                      </SelectTrigger>
                      <SelectContent>
                        {owners.map(owner => (
                          <SelectItem key={owner.id} value={owner.id}>
                            {owner.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button className="w-full bg-primary hover:bg-primary/90">Registrar Mascota</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredPets.map((pet) => (
              <Card key={pet.id} className="p-6 border-border hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent-foreground flex items-center justify-center">
                      <PawPrint className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold">{pet.name}</h3>
                      <p className="text-sm text-muted-foreground">{pet.species}</p>
                    </div>
                  </div>
                  <Badge variant="secondary">{pet.status}</Badge>
                </div>
                <div className="space-y-2 text-sm">
                  <p><span className="text-muted-foreground">Raza:</span> {pet.breed}</p>
                  <p><span className="text-muted-foreground">Edad:</span> {pet.age}</p>
                  <p><span className="text-muted-foreground">Dueño:</span> {pet.ownerName}</p>
                </div>
                <div className="mt-4 flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => navigate(`/historial/${pet.id}`)}
                  >
                    Ver Historial
                  </Button>
                  <Button size="sm" className="flex-1 bg-primary hover:bg-primary/90">
                    Editar
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Clientes Tab */}
        <TabsContent value="clientes" className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Buscar clientes por nombre, teléfono o email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white"
              />
            </div>
            <Dialog>
              <DialogTrigger asChild>
                <Button className="bg-primary hover:bg-primary/90">
                  <Plus className="w-4 h-4 mr-2" />
                  Nuevo Cliente
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Registrar Nuevo Cliente</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label>Nombre Completo</Label>
                    <Input placeholder="Ej. Juan Pérez" />
                  </div>
                  <div className="space-y-2">
                    <Label>Teléfono</Label>
                    <Input placeholder="+52 555-1234" />
                  </div>
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input type="email" placeholder="correo@ejemplo.com" />
                  </div>
                  <div className="space-y-2">
                    <Label>Dirección</Label>
                    <Input placeholder="Calle, número, colonia" />
                  </div>
                  <Button className="w-full bg-primary hover:bg-primary/90">Registrar Cliente</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredOwners.map((owner) => (
              <Card key={owner.id} className="p-6 border-border hover:shadow-md transition-shadow">
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary to-accent-foreground flex items-center justify-center flex-shrink-0">
                    <User className="w-7 h-7 text-white" />
                  </div>
                  <div className="flex-1 space-y-3">
                    <div>
                      <h3 className="font-semibold">{owner.name}</h3>
                      <Badge variant="secondary" className="mt-1">{owner.pets} mascota(s)</Badge>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Phone className="w-4 h-4" />
                        <span>{owner.phone}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Mail className="w-4 h-4" />
                        <span>{owner.email}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin className="w-4 h-4" />
                        <span>{owner.address}</span>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="w-full">
                      Editar Información
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
