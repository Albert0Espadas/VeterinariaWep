import { createBrowserRouter } from "react-router";
import { Layout } from "./components/layout";
import { Dashboard } from "./pages/dashboard";
import { Recepcion } from "./pages/recepcion";
import { PuntoVenta } from "./pages/punto-venta";
import { Consultas } from "./pages/consultas";
import { Citas } from "./pages/citas";
import { HistorialMedico } from "./pages/historial-medico";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: "recepcion", Component: Recepcion },
      { path: "punto-venta", Component: PuntoVenta },
      { path: "consultas", Component: Consultas },
      { path: "citas", Component: Citas },
      { path: "historial/:petId", Component: HistorialMedico },
    ],
  },
]);
