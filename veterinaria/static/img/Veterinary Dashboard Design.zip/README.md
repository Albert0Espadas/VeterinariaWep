
  # Veterinary Dashboard Design

  This is a code bundle for Veterinary Dashboard Design. The original project is available at https://www.figma.com/design/etaBwKDlLdkPklk6uIMgAK/Veterinary-Dashboard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  